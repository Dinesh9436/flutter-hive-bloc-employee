import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_employee_hive_bloc/modules/date_picker.dart';
import 'package:flutter_employee_hive_bloc/widgets/button.dart';
import 'package:flutter_employee_hive_bloc/widgets/form_contailer.dart';

class AddEmployeePage extends StatefulWidget {
  const AddEmployeePage({super.key});

  @override
  State<AddEmployeePage> createState() => _AddEmployeePageState();
}

class _AddEmployeePageState extends State<AddEmployeePage> {
  DateTime? selectedDate;

  Future<void> _showMyDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          insetPadding: EdgeInsets.all(8),
          contentPadding: EdgeInsets.zero,
          clipBehavior: Clip.antiAliasWithSaveLayer,
          scrollable: true,
          content: SingleChildScrollView(
              child: SizedBox(
                  height: MediaQuery.of(context).size.width * 1.4,
                  width: MediaQuery.of(context).size.width,
                  child: CustomDatePicker())),
        );
      },
    );
  }

  void _showBottomSheet(context) {
    showModalBottomSheet(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        backgroundColor: Colors.white,
        context: context,
        builder: (BuildContext buildContext) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Product Designer"),
              ),
              Divider(),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Product Designer"),
              ),
              Divider(),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Product Designer"),
              ),
              Divider(),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Product Designer"),
              ),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Employee Details"),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          FormContainer(
              child: Padding(
                padding: EdgeInsets.only(left: 8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    icon: Icon(
                      Icons.person_outline,
                      color: Theme.of(context).primaryColor,
                    ),
                    hintText: 'Employee name',
                  ),
                ),
              ),
              width: width),
          InkWell(
            onTap: () => _showBottomSheet(context),
            child: FormContainer(
                child: Padding(
                  padding: EdgeInsets.only(left: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Icon(
                              Icons.work_outline,
                              color: Theme.of(context).primaryColor,
                            ),
                          ),
                          Text('Select role')
                        ],
                      ),
                      Icon(
                        Icons.arrow_drop_down,
                        color: Theme.of(context).primaryColor,
                      ),
                    ],
                  ),
                ),
                width: width),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              InkWell(
                onTap: () async => _showMyDialog(),
                //  Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => CustomDatePicker())),
                child: FormContainer(
                    child: Row(
                     // mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Icon(
                            Icons.calendar_month,
                            color: Theme.of(context).primaryColor,
                          ),
                        ),
                        SizedBox(width: 5,),
                        Text('Today')
                      ],
                    ),
                    width: width * 0.35),
              ),
              Icon(
                Icons.arrow_forward,
                color: Theme.of(context).primaryColor,
              ),
              FormContainer(
                  child: Row(
                   // mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Icon(
                          Icons.calendar_month,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      SizedBox(width: 5,),
                      Text('No Date')
                    ],
                  ),
                  width: width * 0.35)
            ],
          ),
          Spacer(),
          Divider(
            height: 1,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              CancelSaveButton(
                title: "Cancel",
                buttonColor: Color(0xFFEDF8FF),
                titleColor: Theme.of(context).primaryColor,
                width: width * 0.2,
              ),
              CancelSaveButton(
                title: "Save",
                buttonColor: Theme.of(context).primaryColor,
                titleColor: Colors.white,
                width: width * 0.2,
              )
            ],
          )
        ],
      ),
    );
  }
}
