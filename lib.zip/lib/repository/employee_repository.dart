import 'package:flutter_employee_hive_bloc/constants/strings.dart';
import 'package:flutter_employee_hive_bloc/db/hive_services.dart';
import 'package:flutter_employee_hive_bloc/models/employee_list.dart';
import 'package:flutter_employee_hive_bloc/utils/utility.dart';

class GroceryRepository {
  /// [GroceryList] Functions --------------------------------------------------

  Future<List<GroceryList>> getAllGroceryLists() async {
    var hasLength = await HiveServices.hasLength<GroceryList>(groceryLists);
    if (!hasLength) return [];

    var data = await HiveServices.getAll<GroceryList>(groceryLists);
    return data;
  }

  Future<bool> checkIfListAlreadyExistsWithTitle(String title) async {
    var data = await HiveServices.getAll<GroceryList>(groceryLists);

    if (data.isNotEmpty) {
      for (var item in data) {
        if (item.title.toLowerCase() == title.toLowerCase()) return true;
      }
    }

    return false;
  }

  Future<GroceryList> addGroceryList(String title) async {
    var uid = AppUtility.generateUid(16);
    AppUtility.log('groceryListUid: $uid');

    var item = GroceryList(
      id: uid,
      title: title,
      itemsCount: 0,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await HiveServices.put<GroceryList>(groceryLists, uid, item);
    return item;
  }

  Future<GroceryList?> updateGroceryList(
    String uid, {
    String? title,
    int? itemsCount,
  }) async {
    var item = await HiveServices.get<GroceryList>(groceryLists, uid);

    if (item == null) return null;

    var tempItem = item;

    if (title != null) {
      tempItem = tempItem.copyWith.title(title);
    }
    if (itemsCount != null) {
      tempItem = tempItem.copyWith.itemsCount(itemsCount);
    }
    tempItem = tempItem.copyWith.updatedAt(DateTime.now());

    AppUtility.log('updatedItem: $tempItem');

    await HiveServices.delete<GroceryList>(groceryLists, uid);
    await HiveServices.put<GroceryList>(groceryLists, uid, tempItem);

    return tempItem;
  }

  Future<void> deleteGroceryList(String id) async {
    if (id.isEmpty) {
      AppUtility.log('id is empty');
      return;
    }

    await HiveServices.delete<GroceryList>(groceryLists, id);
  }

  

  
}
