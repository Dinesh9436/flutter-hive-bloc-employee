const appName = "Grocery List Maker";
const groceryLists = 'groceryLists';
const groceryItems = 'groceryItems';
